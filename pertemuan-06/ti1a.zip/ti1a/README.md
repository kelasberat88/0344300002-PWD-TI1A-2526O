# pertemuan-06

hari ini, tanggal 29 oktober 2025, saya bernama hadi
nim: 2511500010

belajar:
<ol>
<li>hello.php</li>
<li>index.php</li>
<li>copy section#about, rename jadi section#ipk</li>
<li>5x5 variabel matakuliah</li>
<li>5x5 variabel proses dan hasil</li>
<li>memindahkan section#ipk di posisi yang diinginkan</li>
<li>buat skrip menghitung nilai akhir 1 sampai 5</li>
<li>buat kondisi kehadiran di bawah 70, grade = E</li>
<li>buat kondisi status berdasarkan grade</li>
<li>hitung bobot 1 sampai 5</li>
<li>hitung total bobot dan hitung total sks</li>
<li>hitung IPK</li>
</ol>