<!DOCTYPE html>
<html>
<head>
<title>Belajar PHP Dasar</title>
</head>
<body>
<h1><?php echo "Halo, Dunia PHP!"; ?></h1>
</body>
</html>
