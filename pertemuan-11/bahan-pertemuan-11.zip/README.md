# pertemuan-10

saya <b>yohanes setiawan japriadi</b>, pada pertemuan-10 saya belajar:<br>
<ol>
  <li>menghapus index.html dan membuat koneksi.php</li>
  <li>buat database db_pwd2025 menggunakan PHPMyAdmin</li>
  <li>membuat tabel tbl_tamu menggunakan query di PhpMyAdmin</li>
  <li>membuat kode untuk read.php membaca data dari tbl_tamu</li>
  <li>insert data ke tabel tbl_tamu sebanyak 3 record</li>
  <li>akses ulang read.php</li>
  <li>perangkap error query read.php</li>
  <li>duplikat read.php, rename menjadi read_inc.php</li>
  <li>modif struktur kode read_inc.php agar membaca MySQL</li>
  <li>ganti cara menampilkan contact ke include read_inc.php</li>
  <li>hapus kode contact dan fieldcontact di index.php</li>
  <li>export database db_pwd2025</li>
</ol>